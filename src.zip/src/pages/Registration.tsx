import { useState } from "react";

type FormValues = {
  userName: string;
  email: string;
  contact: string;
  password: string;
  role: string;
};

export default function Registration() {
  const [showPwd, setShowPwd] = useState(false);
  const [values, setValues] = useState<FormValues>({
    userName: "",
    email: "",
    contact: "",
    password: "",
    role: "",
  });

  function update<K extends keyof FormValues>(key: K, val: FormValues[K]) {
    setValues(v => ({ ...v, [key]: val }));
  }

  function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    console.log("Submitting", values); // later: send to API
  }

  return (
    <div className="container py-4">
      {/* Breadcrumb / Title */}
      <div className="mb-3">
        <h3 className="fw-semibold mb-0">Access Control <span className="text-body-secondary">/ Registration</span></h3>
      </div>

      {/* Card */}
      <div className="card shadow-sm rounded-4">
        <div className="card-header bg-white py-3">
          <h5 className="mb-0">Registration</h5>
        </div>

        <div className="card-body">
          <form onSubmit={onSubmit} className="row gy-3">
            {/* Row 1: User Name / Email / Contact */}
            <div className="col-md-4">
              <label className="form-label">User Name <span className="text-danger">*</span></label>
              <div className="input-group">
                <span className="input-group-text"><i className="bi bi-person"></i></span>
                <input
                  className="form-control"
                  placeholder="Your username"
                  value={values.userName}
                  onChange={e => update("userName", e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="col-md-4">
              <label className="form-label">Email <span className="text-danger">*</span></label>
              <div className="input-group">
                <span className="input-group-text"><i className="bi bi-envelope"></i></span>
                <input
                  className="form-control"
                  type="email"
                  placeholder="name@example.com"
                  value={values.email}
                  onChange={e => update("email", e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="col-md-4">
              <label className="form-label">Contact <span className="text-danger">*</span></label>
              <div className="input-group">
                <span className="input-group-text"><i className="bi bi-telephone"></i></span>
                <input
                  className="form-control"
                  placeholder="+1 555 123 4567"
                  value={values.contact}
                  onChange={e => update("contact", e.target.value)}
                  required
                />
              </div>
            </div>

            {/* Row 2: Password / Roles */}
            <div className="col-md-6">
              <label className="form-label">Password <span className="text-danger">*</span></label>
              <div className="input-group">
                <span className="input-group-text"><i className="bi bi-lock"></i></span>
                <input
                  className="form-control"
                  type={showPwd ? "text" : "password"}
                  placeholder="•••••"
                  value={values.password}
                  onChange={e => update("password", e.target.value)}
                  required
                />
                <button
                  type="button"
                  className="btn btn-outline-secondary"
                  onClick={() => setShowPwd(s => !s)}
                  title={showPwd ? "Hide" : "Show"}
                >
                  <i className={showPwd ? "bi bi-eye-slash" : "bi bi-eye"}></i>
                </button>
              </div>
            </div>

            <div className="col-md-6">
              <label className="form-label">Roles <span className="text-danger">*</span></label>
              <div className="input-group">
                <span className="input-group-text"><i className="bi bi-people"></i></span>
                <select
                  className="form-select"
                  value={values.role}
                  onChange={e => update("role", e.target.value)}
                  required
                >
                  <option value="">Select Security</option>
                  <option value="admin">Admin</option>
                  <option value="security">Security</option>
                  <option value="user">User</option>
                </select>
              </div>
            </div>

            {/* Submit */}
            <div className="col-12 d-flex justify-content-center pt-2">
              <button className="btn btn-primary px-4" type="submit">Submit</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
