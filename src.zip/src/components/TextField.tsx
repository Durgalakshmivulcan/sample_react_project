import type React from "react";

type Props = {
  id: string;
  label: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  type?: "text" | "email";
  required?: boolean;
  error?: string;
};

export default function TextField({
  id, label, value, onChange, type = "text", required, error
}: Props) {
  return (
    <div style={{ marginBottom: 12 }}>
      <label htmlFor={id} style={{ display: "block", fontWeight: 600 }}>
        {label}
      </label>
      <input
        id={id}
        type={type}
        value={value}
        onChange={onChange}
        required={required}
        style={{ width: "100%", padding: 8, border: "1px solid #101010ff", borderRadius: 6 }}
        aria-invalid={!!error}
        aria-describedby={error ? `${id}-error` : undefined}
        autoComplete={id}
      />
      {error && (
        <div id={`${id}-error`} style={{ color: "#b91c1c", fontSize: 12, marginTop: 4 }}>
          {error}
        </div>
      )}
    </div>
  );
}
